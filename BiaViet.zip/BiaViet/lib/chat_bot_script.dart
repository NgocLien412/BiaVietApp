// import 'package:flutter/material.dart';
// import 'package:google_nav_bar/google_nav_bar.dart';
// import 'chat_bot_script.dart'; // Import file kịch bản chatbot
//
// class ChatBotScript {
//   // Constructor
//   ChatBotScript();
//
//   // Method to generate responses based on user input
//   String getResponse(String input) {
//     final lowerInput = input.toLowerCase();
//
//     // Basic keyword-based responses
//     if (lowerInput.contains('hello') || lowerInput.contains('hi')) {
//       return 'Xin chào! Hôm nay tôi có thể giúp gì cho bạn?';
//     } else if (lowerInput.contains('how are you')) {
//       return 'Tôi chỉ là một robot nhưng tôi ở đây để giúp đỡ! Tôi có thể giúp gì cho bạn?';
//     } else if (lowerInput.contains('help')) {
//       return 'Chắc chắn! Hãy cho tôi biết bạn cần giúp đỡ điều gì.';
//     } else if (lowerInput.contains('thanks') || lowerInput.contains('thank you')) {
//       return 'Không có gì! Hãy cho tôi biết nếu có bất cứ điều gì khác.';
//     } else {
//       // Default response for unrecognized inputs
//       return 'Sorry, I didn’t quite understand that. Could you please rephrase?';
//     }
//   }
// }
